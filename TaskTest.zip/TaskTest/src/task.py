class Task:
    def __init__(self, task_id, description, done=False):
        self.task_id = task_id
        self.description = description
        self.done = done
