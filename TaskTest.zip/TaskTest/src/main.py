from task import Task
from taskmanager import TaskManager


def main():
    task_manager = TaskManager()

    while True:
        print("1. Adicionar tarefa")
        print("2. Listar tarefas")
        print("3. Marcar tarefa como concluída")
        print("4. Remover tarefa")
        print("5. Sair")

        choice = input("Escolha uma opção: ")

        if choice == "1":
            task_id = int(input("Digite o ID da tarefa: "))
            description = input("Digite a descrição da tarefa: ")
            task = Task(task_id, description)
            task_manager.add_task(task)
            print("Tarefa adicionada")

        elif choice == "2":
            tasks = task_manager.list_tasks()
            if not tasks:
                print("Nenhuma tarefa encontrada.")
            else:
                print("Lista de tarefas:")
                for task in tasks:
                    status = "Concluída" if task.done else "Não concluída"
                    print(f"ID: {task.task_id} - Descrição: {task.description} - Status: {status}")

        elif choice == "3":
            task_id = int(input("Digite o ID da tarefa que deseja marcar como concluída: "))
            task_manager.mark_task_done(task_id)
            print("Tarefa marcada como concluída com sucesso!")

        elif choice == "4":
            task_id = int(input("Digite o ID da tarefa que deseja remover: "))
            task_manager.remove_task(task_id)
            print("Tarefa removida")

        elif choice == "5":
            print("Encerrando o programa...")
            break

        else:
            print("Essa opção não existe, selecione uma opção existente")

if __name__ == "__main__":
    main()
