import pytest
from ..src.task import Task
from ..src.taskmanager import TaskManager

def test_task_manager_integration():
    
    task_manager = TaskManager()

    task_manager.add_task(Task(1, "Arrumar a cama"))
    task_manager.add_task(Task(2, "Tomar banho"))
    task_manager.add_task(Task(3, "Chrorar"))

    tasks = task_manager.list_tasks()
    assert len(tasks) == 3
    assert tasks[0].task_id == 1
    assert tasks[0].description == "Arrumar a cama"
    assert not tasks[0].done
    assert tasks[1].task_id == 2
    assert tasks[1].description == "Tomar banho"
    assert not tasks[1].done
    assert tasks[2].task_id == 3
    assert tasks[2].description == "Chrorar"
    assert not tasks[2].done

    task_manager.mark_task_done(2)

    tasks = task_manager.list_tasks()
    assert len(tasks) == 3
    assert tasks[0].task_id == 1
    assert tasks[0].description == "Arrumar a cama"
    assert not tasks[0].done
    assert tasks[1].task_id == 2
    assert tasks[1].description == "Tomar banho"
    assert tasks[1].done
    assert tasks[2].task_id == 3
    assert tasks[2].description == "Chrorar"
    assert not tasks[2].done

    task_manager.remove_task(1)

    tasks = task_manager.list_tasks()
    assert len(tasks) == 2
    assert tasks[0].task_id == 2
    assert tasks[0].description == "Tomar banho"
    assert tasks[0].done
    assert tasks[1].task_id == 3
    assert tasks[1].description == "Chrorar"
    assert not tasks[1].done